#include<bits/stdc++.h>
using namespace std;

void calculate(vector<int> *A,int *F,int n)
{
	for(int i=1;i<=n;i++)
	{		
		vector<int>::iterator it;
		stack<int> st;
		st.push(i);
		int L[n+1];
		for(int j=0;j<=n;j++)
		L[j]=0;
		while(!st.empty())
		{
			int x = st.top();
			st.pop();
			for(it=A[x].begin();it!=A[x].end();it++)
			{
				{
					st.push(*it);
					L[*it]=L[x]+1;
				}
			}
		}
		
		int maxm=0;
		for(int i=1;i<=n;i++)
		{
			maxm = max(L[i],maxm);
		}
		
		F[i]=maxm;
	}
	
	for(int i=1;i<=n;i++)
	cout<<F[i]<<" ";
}

int main()
{
	char P[5][5];
	
	for(int i=1;i<=4;i++)
	for(int j=1;j<=4;j++)
	cin>>P[i][j];
	
	vector<int> A[9];
	
 	for(int i=1;i<=4;i++)
 	for(int j=1;j<=4;j++)
 	{
 		if(P[i][j]=='>')
		 A[i].push_back(j+4);
		else if(P[i][j]=='<')
			A[j+4].push_back(i);	
	}
	
	int F[9];
	
	calculate(A,F,8);
}
