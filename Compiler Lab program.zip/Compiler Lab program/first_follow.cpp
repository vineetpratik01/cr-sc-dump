#include<iostream>
using namespace std;
#include<map>
#include<vector>
#include<set>

vector<string> prod;
map<char,set<char> > first,follow;
set<char> terminals,non_terminals;
char start;

bool isTerminal(char ch)
{
	if(terminals.find(ch) != terminals.end())
	{
		return true;
	}
	return false;
}

set<char> find_first(char ch)
{
	int ln,j,k;
	set<char> temp;
	if(!(isTerminal(ch)))
	{
		temp.insert(ch);
		return temp;
	}
	map<char,set<char> > :: iterator mitr = first.find(ch);
	if(mitr != first.end())
	{
		return (*(mitr)).second;
	}
	vector<string> :: iterator itr;
	string str;
	for(itr = prod.begin();itr != prod.end();itr++)
	{
		str = *(itr);
		if(str[0] == ch)
		{
			ln = str.length();
			bool flag = false;
			for(j = 3;j<ln;j++)
			{
				set<char> rt = find_first(str[j]);
				bool null_present = false;
				set<char> :: iterator it = rt.begin();
				for(;it != rt.end();it++)
				{
					if(*(it) == '#')
					{
						null_present = true;
					}
					else
					{
						temp.insert(*it);
					}
				}
				if(null_present == false)
				{
					flag = true;
					break;
				}
			}
			if(flag == false)
			{
				temp.insert('#');
			}
		}
	}
	return temp;
}

set<char> find_follow(char ch)
{
	string str;
	int ln,j;
	map<char,set<char> > :: iterator mitr = follow.find(ch);
	if(mitr != follow.end())
	{
		return (*(mitr)).second;
	}
	
	set<char> temp;
	if(ch == start)
	{
		temp.insert('$');
	}
	vector<string> :: iterator itr;
	for(itr = prod.begin();itr != prod.end();itr++)
	{
		str = *(itr);
		ln = str.length();
		for(j = 3;j<ln;j++)
		{
			if(str[j] == ch)
			{
				while(true)
				{
					if(j == ln-1)
					{
						if(str[0] != ch)
						{
							set<char> nt = find_follow(str[0]);
							set<char> :: iterator it;
							for(it = nt.begin();it != nt.end();it++)
							{
								temp.insert(*(it));
							}
						}
						break;
					}
					else if(str[j+1] == '#')
					{
						if(str[0] != ch)
						{
							set<char> nt = find_follow(str[0]);
							set<char> :: iterator it;
							for(it = nt.begin();it != nt.end();it++)
							{
								temp.insert(*(it));
							}
						}
						break;
					}
					else
					{
						set<char> nt = find_first(str[j+1]);
						set<char> :: iterator it;
						bool null_present = false;
						for(it = nt.begin();it != nt.end();it++)
						{
							if(*(it) == '#')
							{
								null_present = true;
							}
							else
							{
								temp.insert(*(it));
							}
						}
						if(null_present == false)
						{
							break;
						}
						j++;
					}
				}
				break;
			}
		}
	}
	return temp;
}

int main()
{
	int n,i;
	string str;
	cout<<"Enter the number of productions in the grammar\n";
	cin>>n;
	cout<<"Enter the productions \n";
	for(i = 1;i<=n;i++)
	{
		cin>>str;
		terminals.insert(str[0]);
		prod.push_back(str);
	}
	start = prod[0][0];
	set<char> :: iterator itr;
	for(itr = terminals.begin();itr != terminals.end();itr++)
	{
		first.insert(make_pair(*(itr),find_first(*(itr))));
	}
	for(itr = terminals.begin();itr != terminals.end();itr++)
	{
		follow.insert(make_pair(*(itr),find_follow(*(itr))));
	}
	map<char,set<char> > :: iterator itr1;
	cout<<"FIRST ------------------------->>>>>>>>>>>>>>>>>\n";
	for(itr1 = first.begin();itr1 != first.end();itr1++)
	{
		set<char> s = (*itr1).second;
		cout<<(*itr1).first<<" : ";
		for(itr = s.begin();itr != s.end();itr++)
		{
			cout<<(*itr)<<" ";
		}
		cout<<"\n";
	}
	cout<<"FOLLOW ------------------------->>>>>>>>>>>>>>>>>\n";
	for(itr1 = follow.begin();itr1 != follow.end();itr1++)
	{
		set<char> s = (*itr1).second;
		cout<<(*itr1).first<<" : ";
		for(itr = s.begin();itr != s.end();itr++)
		{
			cout<<(*itr)<<" ";
		}
		cout<<"\n";
	}
}
