#include<bits/stdc++.h>
using namespace std;
    
struct pair_hash
{
    template <class T1, class T2>
    std::size_t operator() (const std::pair<T1, T2> &pair) const
    {
        return std::hash<T1>()(pair.first) ^ std::hash<T2>()(pair.second);
    }
};

unordered_map< pair<int,int>, int, pair_hash > wt;
    
void addEdge(list<int> adj[], int u, int v, int w ){
    adj[u].push_back(v);
    wt.insert(make_pair(make_pair(u,v), w));
}
    
void topo( list<int> adj[], int src, int visited[], int a[], int &time)
{
    visited[src] = 1;
    time++;
    
    for( auto i = adj[src].begin(); i != adj[src].end(); i++ ){
        if( !visited[*i] ){
        topo(adj,*i, visited, a, time);
        }
    }
    a[src] = time++;
}

int main(){
    int v = 6;
    list<int> adj[v+1];
    
    addEdge(adj,1,2,2); 
    addEdge(adj,1, 3,2);
    addEdge(adj,2,5,3 );
    addEdge(adj, 2,4,4);
    addEdge(adj, 3,6,8);
    addEdge(adj, 5,6,6);
    addEdge(adj, 4,5,0);
    
    int visited[v+1];
    int a[v+1];
    memset(visited,0 ,sizeof(int)*(v+1));
    memset(a, -1, sizeof(a));
    int time = 0;
    for(int i = 1; i < v+1; i++ ){
        topo( adj, i, visited, a, time );
        while( i < v+1 && visited[i] ){
            i++;
        }
    }
    
    int topology[2*v +2];
    int f[v+1], b[v+1], totalDays = 0;
    memset(f,0,sizeof(f));
    memset(topology,-1, sizeof(topology));
    for( int i = 1; i < v+1; i++){
        topology[a[i]] = i;
    }
    
    for( int i = 2*v+1; i>0 ; i--){
        if(topology[i] != -1){
            for( auto itr = adj[topology[i]].begin(); itr!= adj[topology[i]].end(); itr++ )
            {
                if( f[topology[i]] + wt[make_pair(topology[i],*itr)] > f[*itr] )
                    f[*itr] = f[topology[i]] + wt[make_pair(topology[i],*itr)];
            }
        }
    }
        
    for(int i = 1; i <= v; i++ ){
        totalDays = max(totalDays, f[i]);
    }
    
    cout<<"\nTotal Days to complete the work is: "<<totalDays<<" Days"<<endl;
    for(int i = 0; i <= v; i++) {
        b[i] = totalDays;
    }
    for( int i = 0; i < 2*v+1 ; i++){
        if(topology[i] != -1){
            for( auto itr = adj[topology[i]].begin(); itr!= adj[topology[i]].end(); itr++ )
            {
                if( b[*itr] - wt[make_pair(topology[i], *itr)] < b[topology[i]] )
                    b[topology[i]] = b[*itr] - wt[make_pair(topology[i], *itr)] ;
            }
        }
    }
    
    cout<<"Forward Pass:"<<endl;
    for(int i = 1; i < v+1 ; i++ ){
        cout<<i<<" : "<<f[i]<<endl;
    }
    
    cout<<"Backward Pass:"<<endl;
    for(int i = 1; i < v+1 ; i++ ){
        cout<<i<<" : "<<b[i]<<endl;
    }
    
    cout<<"\nCritical path:"<<endl;
    for(int i = 1; i < v+1 ; i++){
        //cout<<"f: "<<f[i]<<" b: "<<b[i]<<endl;
        
        if( f[i] == b[i] ){
            cout<<i<<"->";
        }
    }
    cout<<"end!!\n"<<endl;
    return 0;
}

// INPUT:  //INTPUT PROVIDED IN THE PROGRAM


// OUTPUT:

// Total Days to complete the work is: 12 Days
// Forward Pass:
// 1 : 0
// 2 : 2
// 3 : 2
// 4 : 6
// 5 : 6
// 6 : 12
// Backward Pass:
// 1 : 0
// 2 : 2
// 3 : 4
// 4 : 6
// 5 : 6
// 6 : 12

// Critical path:
// 1->2->4->5->6->end!!

// *****************************
