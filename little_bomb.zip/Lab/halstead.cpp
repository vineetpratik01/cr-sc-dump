#include <bits/stdc++.h>
 
using namespace std;
 
class Halsteads {
    string str;
    bool isCommentBlock = 0;
    int noOperator = 0;
    int noOperand = 0;
    set<string>distinctOperator, distinctOperand;
 
    string pureOperators[200] = { "::", "++", "--", "(", ")", "[", "]", ".", "->", "!", "~", ",",
        "->*", "*", "/", "%", "+", "-", "<<", ">>", "<", "<=", ">", ">=", "==", "!=", "&", "^", "|", "&&", 
        "||", "?:", "=", "+=", "-=", "*=", "/=", "%=", "<<=", ">>=", "&=", "^=", "|=", ",", ";", "{", "}" };
 
    string reserverWords[84] = {"alignas", "alignof", "and", "and_eq", "asm", "auto", "bitand", "bitor",
    "bool", "break", "case", "catch", "char", "char16_t", "char32_t", "class",
    "compl", "const", "constexpr", "const_cast", "continue", "decltype",
    "default", "delete", "do", "double", "dynamic_cast", "else", "enum",
    "explicit", "export", "extern", "false", "float", "for", "friend", "goto",
    "if", "inline", "int", "long", "mutable", "namespace", "new", "noexcept",
    "not", "not_eq", "nullptr", "operator", "or", "or_eq", "private",
    "protected", "public", "register", "reinterpret_cast", "return", "short",
    "signed", "sizeof", "static", "static_assert", "static_cast", "struct",
    "switch", "template", "this", "thread_local", "throw", "true", "try",
    "typedef", "typeid", "typename", "union", "unsigned", "using", "virtual",
    "void", "volatile", "wchar_t", "while", "xor", "xor_eq"};
 
    void halsteadsAlgo(string line) {
        // Remove starting space
        int i = 0;
        while (line.size() and line[i] == ' ') {i++;}
        line = line.substr(i);
 
        // 1. Ignored hash directive
        if (line.size() and line[0] == '#')
            return ;
 
        // check termination of commentsBlock
        if (line.size() >= 2 and line[line.size() - 2] == '*' and line[line.size() - 1] == '/') {
            isCommentBlock = 0;
            return ;
        }
 
        // 2. comments are not considered
        if (isCommentBlock or line.size() >= 2 and line[0] == line[1] and line[1] == '/')
            return ;
 
        // 2.1 comments of type /* ... */
        if (line.size() >= 2 and line[0] == '/' and line[1] == '*') {
            isCommentBlock = 1;
            return ;
        }
 
        else {
            stringstream iss(line);
            string word;
            while(iss >> word) {
                bool f = 0;
                for (auto s : reserverWords) {
                    if (s == word) {
                    	noOperator++;
                    	distinctOperator.insert(word);
                        f = 1;
                    }
                }
                for (auto s : pureOperators) {
                    if (s == word) {
                    	noOperator++;
                    	distinctOperator.insert(word);
                        f = 1;
                    }
                }
                if (!f) {
                   noOperand++;
                   distinctOperand.insert(word);
                }
            }
        }
 
    }
    
    public:
        Halsteads (string file) {
            solve(file);
        }
        void solve(string file) {
            ifstream myFile(file);
            int j = 0;
            if (myFile.is_open()) {
                while (getline(myFile, str)) {
                    halsteadsAlgo(str);
                }
                myFile.close();
            }
            printf("Number of Operator are: %d and operand are: %d\n", noOperator, noOperand);
            printf("Number of Distinct Operator are: %d and Distinct operand are: %d\n", distinctOperator.size(), distinctOperand.size());
            int n1, n2, N1, N2;
            n1 = distinctOperator.size();
            n2 = distinctOperand.size();
            N1 = noOperator;
            N2 = noOperand;
            cout<<"Program Length "<<N1 + N2<<endl;
            cout<<"Estimated Program Length "<<n1 * log2(n1) + n2* log2(n2)<<endl;
            cout<<"Vocabulary "<<n1 + n2<<endl;
            cout<<"Program Difficulty "<<(n1 / 2.0) * (N2 / n2)<<endl;
            cout<<"Program Volume "<<(N1 + N2) * log2(n1 + n2)<<endl;
            cout<<"Program Effort "<<(N1 + N2) * log2(n1 + n2) * (n1 / 2) * (N2 / n2)<<endl;
        }
};
 
int main() {
    Halsteads obj("merge_sort.txt");
}


// Input- Merge Sort Algorithm

// Output-

// Number of Operator are: 220 and operand are: 137
// Number of Distinct Operator are: 21 and Distinct operand are: 50
// Program Length 357
// Estimated Program Length 374.431
// Vocabulary 71
// Program Difficulty 21
// Program Volume 2195.46
// Program Effort 43909.2
