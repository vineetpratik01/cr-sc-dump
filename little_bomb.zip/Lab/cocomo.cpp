#include <bits/stdc++.h>
using namespace std;

double val[3][4] = {{3.2, 1.05, 2.8, 0.38},
                   {3.0, 1.12, 2.8, 0.35},
                   {2.8, 1.20, 2.8, 0.32}};
                   
double effort(int a1, int a2, int kloc){
        return (double)(a1 * pow(kloc,a2));
}

double time_for_dev(int b1, int b2, int effort){
        return (double)(b1 * pow(effort,b2));
}

double staff(double effort, double Tdev){
        return (double)(effort / Tdev);
}

double productivity(double staff, double Tdev){
        return (double)(staff / Tdev);   
}

void calc(int kloc,int i){
        double calc_effort = effort(val[i][0],val[i][1],kloc);
        double calc_tdev = time_for_dev(val[i][2],val[i][3],calc_effort);
        double calc_staff = staff(calc_effort , calc_tdev);
        double calc_prod = productivity(calc_staff , calc_tdev);

        cout<<"Effort = "<<calc_effort<<"\n"
            <<"Time for development = "<<calc_tdev<<"\n"
            <<"Staff = "<<calc_staff<<"\n"
            <<"Productivity = "<<calc_prod<<"\n";
}

int main(){
    cout<<"Enter KLOC : ";
    int kloc;cin>>kloc;
    if(kloc < 50)
        calc(kloc,0);
    else if(kloc>=50 && kloc<300)
        calc(kloc,1);
    else
        calc(kloc,2);   
    return 0;
}


// Input- Enter KLOC- 50

// Output- 

// Effort = 150
// Time for development = 2
// Staff = 75
// Productivity = 37.5
