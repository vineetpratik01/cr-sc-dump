#include <bits/stdc++.h>
using namespace std;
 
struct pair_hash
{
    template <class T1, class T2>
    std::size_t operator() (const std::pair<T1, T2> &pair) const
    {
        return std::hash<T1>()(pair.first) ^ std::hash<T2>()(pair.second);
    }
};
 
unordered_map< pair<int,int>, int, pair_hash > wt;
unordered_map< pair<int,int>, double, pair_hash > var;
 
void addEdge(list<int> adj[], int u, int v, double o , double m , double p ){
	int w = (o+4*m+p)/6;
	cout<<u<<"->"<<v<<": "<<w<<"  ";
	var.insert( make_pair( make_pair(u,v), (p-o)*(p-o)/36));
	cout<< (p-o)*(p-o)/36<<endl;
    adj[u].push_back(v);
    wt.insert(make_pair(make_pair(u,v), w));
}
 
void topo( list<int> adj[], int src, int visited[], int a[], int &time)
{
    visited[src] = 1;
    time++;
 
    for( auto i = adj[src].begin(); i != adj[src].end(); i++ ){
        if( !visited[*i] ){
        topo(adj,*i, visited, a, time);
        }
    }
    a[src] = time++;
}
 
int main(){
    int v = 8;
    list<int> adj[v+1];
    cout<<"weights:\n";
    addEdge(adj, 1,2,5,6,7); 
    addEdge(adj, 1, 3, 1,3,5);
    addEdge(adj, 1,4,1,4,7 );
    addEdge(adj, 2,5, 1,2,3);
    addEdge(adj, 3,6, 1,2,9);
    addEdge(adj, 4,6,1,5,9);
    addEdge(adj, 4,7,2,2,8);
	addEdge(adj, 5,8, 2,5,8);
	addEdge(adj, 6,7,4,4,10);
	addEdge(adj, 7,8,2,2,8);
 
    int visited[v+1];
    int a[v+1];
 
    memset(visited,0 ,sizeof(int)*(v+1));
    memset(a, -1, sizeof(a));
 
    int time = 0;
    for(int i = 1; i < v+1; i++ ){
        topo( adj, i, visited, a, time );
        while( i < v+1 && visited[i] ){
            i++;
        }
    }
 
    int topology[2*v +2];
    int f[v+1], b[v+1], totalDays = 0;
    memset(f,0,sizeof(f));
 
 
    memset(topology,-1, sizeof(topology));
    for( int i = 1; i < v+1; i++){
        topology[a[i]] = i;
    }
 
    for( int i = 2*v+1; i>0 ; i--){
        if(topology[i] != -1){
            for( auto itr = adj[topology[i]].begin(); itr!= adj[topology[i]].end(); itr++ )
            {
                if( f[topology[i]] + wt[make_pair(topology[i],*itr)] > f[*itr] )
                    f[*itr] = f[topology[i]] + wt[make_pair(topology[i],*itr)];
            }
        }
    }
 
    for(int i = 1; i <= v; i++ ){
        totalDays = max(totalDays, f[i]);
    }
 
    cout<<"\nTotal Days to complete the work is: "<<totalDays<<" Days"<<endl;
    for(int i = 0; i <= v; i++) {
        b[i] = totalDays;
    }
 
    for( int i = 0; i < 2*v+1 ; i++){
        if(topology[i] != -1){
            for( auto itr = adj[topology[i]].begin(); itr!= adj[topology[i]].end(); itr++ )
            {
                if( b[*itr] - wt[make_pair(topology[i], *itr)] < b[topology[i]] )
                    b[topology[i]] = b[*itr] - wt[make_pair(topology[i], *itr)] ;
            }
        }
    }
 
    cout<<"Forward Pass:"<<endl;
    for(int i = 1; i < v+1 ; i++ ){
        cout<<i<<" : "<<f[i]<<endl;
    }
 
    cout<<"Backward Pass:"<<endl;
    for(int i = 1; i < v+1 ; i++ ){
        cout<<i<<" : "<<b[i]<<endl;
    }
 
	int flag  = 0;
	int a1;
    double p_v = 0 ;
    cout<<"\nCritical path:"<<endl;
    for(int i = 1; i < v+1 ; i++){
        if( f[i] == b[i] ){
			if( flag == 1){
				p_v += var[make_pair(a1, i)];
				a1 = i;
			}
 
			if(flag == 0){
				flag = 1;
				a1 = i;
			}
 
            cout<<i<<"->";
        }
    }
    cout<<"end!!\n"<<endl;
    cout<<"project variance: "<<p_v<<endl;
    return 0;
}








// INPUT: //Provided in the input

// OUTPUT:
// weights:
// 1->2: 6  0.111111
// 1->3: 3  0.444444
// 1->4: 4  1
// 2->5: 2  0.111111
// 3->6: 3  1.77778
// 4->6: 5  1.77778
// 4->7: 3  1
// 5->8: 5  1
// 6->7: 5  1
// 7->8: 3  1

// Total Days to complete the work is: 17 Days
// Forward Pass:
// 1 : 0
// 2 : 6
// 3 : 3
// 4 : 4
// 5 : 8
// 6 : 9
// 7 : 14
// 8 : 17
// Backward Pass:
// 1 : 0
// 2 : 10
// 3 : 6
// 4 : 4
// 5 : 12
// 6 : 9
// 7 : 14
// 8 : 17

// Critical path:
// 1->4->6->7->8->end!!

// project variance: 4.77778
